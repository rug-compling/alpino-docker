# config.sh     pajas@ufal.mff.cuni.cz     2010/03/30 14:26:10

local_pm=(
  Fslib
)
