package Alien::Libxml2::Install::Files;
use strict;
use warnings;
require Alien::Libxml2;
sub Inline { shift; Alien::Libxml2->Inline(@_) }
1;

=begin Pod::Coverage

  Inline

=cut
