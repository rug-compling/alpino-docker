package Test2::AsyncSubtest::Formatter;
use strict;
use warnings;

our $VERSION = '0.000159';

die "Should not load this anymore";

1;
