package CSTS_SGML_SP_Backend;
# pajas@ufal.mff.cuni.cz          30 b�e 2010

use Treex::PML::Backend::CSTS ();

1;
